#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import re
from tqdm import tqdm


# In[35]:


holiday=pd.read_csv('holiday.csv',encoding='utf-8',names=['date','is_holiday'])
data=pd.read_csv('invoice_qmonster.csv',encoding='utf-8',names=['inv_id','item_no','product_name','unit_price','quantity','amonut','inv_time','login_time','company_name','seller_address'	,'uuid','gender','age'],index_col=None)
weather=pd.read_csv('weather2.csv',encoding='utf-8')
cpi=pd.read_csv('cpi_2.csv',encoding='utf-8')


# In[36]:


#檢查每個欄位的缺失值
col=data.columns
for c in col:
    print(c,':',data[c].isnull().sum())


# In[37]:


#刪除有缺失值的row
data=data.dropna(subset=['product_name'])
data=data.dropna(subset=['gender','age'])
data=data.dropna(subset=['seller_address'])


# In[39]:


# -*- coding: utf-8 -*-
"""
整理holiday且合併data及holiday
"""
#change / to -
holiday['date']=holiday['date'].astype(str).apply(lambda x: x.replace("/", "-"))
holiday['date']=pd.to_datetime(holiday['date'])
holiday['date'] = holiday['date'].astype(str)

data['inv_time']=pd.to_datetime(data['inv_time'])
#data['date'] = [d.date() for d in data['inv_time']]
data['date'] = data['inv_time'].apply(lambda x: x.date()) #這樣寫也很久
#data['time'] = [d.time() for d in data['inv_time']]
data['time'] = data['inv_time'].apply(lambda x: x.time())
data['date']=data['date'].astype(str)
#拿掉其他欄位 因為資料太大
data=data[['inv_time','date', 'time','seller_address','inv_id']]
data=data.merge(holiday,on=['date'])




# In[40]:


''''address processing''' 

#修正前面有地址or臺北(非台北)的地址
data['seller_address']=data['seller_address'].apply(lambda x: x.replace('地址:',''))
data['seller_address']=data['seller_address'].apply(lambda x: x.replace('臺','台'))
data['seller_address']=data['seller_address'].apply(lambda x: x.replace('台灣',''))
data['seller_address']=data['seller_address'].apply(lambda x: x.replace(' ',''))


#修正ex:300新竹市有郵遞區號的row
def del_post_number(x):
    a=re.findall(r'\d+', x)
    if len(a)>=1:
        for i in a:
            x=x.replace(i,'')
    return x

data['seller_address']=data['seller_address'].apply(del_post_number)


#修正 ex:北市or竹縣縮寫的地址
def change_abbreviate(real_data,word,replace_word):
    a=pd.Series(real_data[real_data['seller_address']==word]['seller_address'].index)
    for d in a:
        real_data['seller_address'][d]=replace_word       
word='北'
replace_word='台北'
change_abbreviate(data, word, replace_word)


#遺失值以max填入
#spliting 
def county(x,num):
    if len(str(x).split('縣'))>=num:
        return x.split('縣',1)
    elif len(str(x).split('市'))>=num:
        return x.split('市',1) 
    else :
        return x


data['county']=data['seller_address'].apply(county,args=(2,))


# In[41]:


#a=real_data[(real_data['len']!=2)].index
#real_data=real_data.drop(a)
data[['county','area']]=pd.DataFrame(data['county'].tolist()).iloc[:,:2]#新增欄位 country area
data['county']=data['county'].apply(county,args=(2,))
road=data[data['county'].apply(lambda x: isinstance(x, list))]#road :找切的不乾淨的row(ex:心北市板橋區縣民大道)
road=road.reset_index()
total_road=road[['index','area']]

#切乾淨後回填

    
 


# In[42]:


r=pd.DataFrame(road['county'].tolist(),columns=['county','area'])
r.index=road['index']


# In[43]:


road['county']=r['county']
road['area']=r['area']


# In[44]:


road.index=r.index


# In[45]:


road=road.drop(columns=['index'])


# In[46]:


real_data=real_data.drop(r.index)


# In[47]:


real_data=real_data.append(road)


# In[49]:


road['county']=r['county']
road['area']=r['area']
real_data=real_data.drop(r.index)
real_data=real_data.append(road)


# In[54]:


road=road.reset_index()


# In[55]:


road['area']=total_road['area']


# In[57]:


road.to_csv('road.csv')


# In[2]:


road=pd.read_csv('road.csv')


# In[3]:


road.index=road['index']
road=road.drop(columns=['Unnamed: 0'])


# In[4]:


road


# In[62]:


data=data[(data['county']=='台北')]


# In[6]:


#切開area ex:板橋區 湖口鄉....ok是避免切兩次
def area(x,num,ok):      
    if len(str(x).split('區'))>=num:
        ok=1
        return x.split('區',1)
    elif (len(str(x).split('鎮'))>=num)&(ok==0):
        ok=1
        return x.split('鎮',1) 
    elif (len(str(x).split('市'))>=num)&(ok==0):
        ok=1
        return x.split('市',1) 
    elif (len(str(x).split('鄉'))>=num)&(ok==0):
        ok=1
        return x.split('鄉',1) 
    else :
        return x

data['area2']=data['area'].apply(area,args=(2,0))


# In[7]:


a=data[['area2']]


# In[8]:


a['len']=a['area2'].apply(lambda x:isinstance(x,float))


# In[9]:


a=a[a['len']==True]


# In[10]:


data=data.drop(a.index)


# In[11]:


data


# In[12]:


real_data[['area3','area4']]=pd.DataFrame(real_data['area2'].tolist()).iloc[:,:2]


# In[13]:


road


# In[19]:


road['seller_address'][16722445]


# In[20]:


data=data.drop(real_data[real_data['area4'].apply(lambda x: isinstance(x,float))].index)


# In[29]:


data


# In[22]:


data.index=data['Unnamed: 0']
data=data.drop(columns=['Unnamed: 0'])
road=road.drop(columns=['index'])


# In[30]:




#沒有行政單位者ex:台北市光復南路(沒有大安區)
#area2沒有成功被切分成list代表裡面沒有行政區
road2=data[data['area2'].apply(lambda x: isinstance(x, str))]
query=pd.DataFrame(road2['seller_address'].unique(),columns=['seller_address'])
query['area3']=0
query['road']=0


# In[6]:


API_KEY='AIzaSyAzxVWS5a16m_MvaYiyYZpDfJc-lrA4qYM'
import googlemaps
from google.cloud import translate_v2 as translate
import os
os.environ['GOOGLE_APPLICATION_CREDENTIALS']=r'trans.json'
a=translate.Client()
gmaps=  googlemaps.Client(key=API_KEY)


# In[51]:



#google geocode api 查詢完整地址取出行政區再翻譯成中文之後回填用cloud translate api
for index,address in tqdm( zip(query.index,query['seller_address'])):
#text='Zhongzheng District'
    ad=gmaps.geocode(address) 
    ad=ad[0]
    try:
        place=ad['formatted_address'].split(', ')[-3]
    except:
        place=ad['formatted_address'].split(', ')[-2]
    output=a.translate(place,source_language='en',target_language='zh_tw')
    #output_road=a.translate(rp,source_language='en',target_language='zh_tw')
    query['area3'][index]=output['translatedText']
    #query['road'][index]=output_road['translatedText']

    
query['area3']=query['area3'].apply(lambda x: x.replace('區',''))
test=real_data
test=test.reset_index()
test=test.merge(query,on=['seller_address'])





# In[53]:


query.to_csv('query.csv')


# In[55]:


test['area3_y']=test['area3_y'].str.replace('靈','苓')


# In[57]:


test.to_csv('test.csv')


# In[72]:


test=pd.read_csv('test.csv')


# In[65]:


real_data2


# In[74]:


test=test.drop(columns=['Unnamed: 0'])


# In[76]:


test=test.drop(columns=['road'])


# In[84]:


real_data=real_data2


# In[78]:


test=test.drop(columns=['area3_x'])


# In[79]:


test=test.rename(columns={"area3_y": "area3"})


# In[85]:





# In[80]:


test


# In[86]:


real_data2=real_data
index=test['Unnamed: 0.1']
test.index=test['Unnamed: 0.1']
real_data=real_data.drop(index)
real_data=real_data.append(test)


# In[88]:


real_data=real_data.drop(columns=['Unnamed: 0.1'])


# In[89]:


real_data


# In[90]:


real_data.to_csv('real_data_district.csv')


# In[2]:


real_data=pd.read_csv('real_data_district.csv')


# In[4]:


real_data.index=real_data['Unnamed: 0']
real_data=real_data.drop(columns=['Unnamed: 0'])
real_data


# In[17]:


##road

def road(x,num,ok):      
    if len(str(x).split('里'))>=num:
        ok=1
        return x.split('里',1)
    elif (len(str(x).split('街'))>=num)&(ok==0):
        ok=1
        return x.split('街',1) 
    elif (len(str(x).split('道'))>=num)&(ok==0):
        ok=1
        return x.split('道',1) 
    elif (len(str(x).split('村'))>=num)&(ok==0):
        ok=1
        return x.split('村',1) 
    elif (len(str(x).split('路'))>=num)&(ok==0):
        ok=1
        return x.split('路',1) 
    
    
    
data['area5']=data['area4'].apply(road,args=(2,0))
#nonetype
data['area5']=data['area5'].fillna(0)
data=data.reset_index()



# In[21]:


data=data.dropna(axis=0)


# In[2]:


from tqdm import tqdm


# In[24]:




def get_road(x):
    if(type(x)==list):
        a=x[0]
        return a
    else:
        return x   
real_data['area5']=real_data['area5'].apply(get_road)


'''經費不足(得到location type)
#location type
location=pd.DataFrame(real_data['seller_address'].unique(),columns=['seller_address'])
location['location_type']=0 

for index,address in zip(location.index,location['seller_address']):
    try:
        ad=gmaps.geocode(address) 
        ad=ad[0]['geometry']['location']
        a=gmaps.places_nearby(location='25.0436529,121.5323979',radius=1)
        location['location_type'][index]=ad['geometry']['location_type']
    
    except:
        pass

'''


#''''weather 得到每日該行政區的平均溫度和平均雨量


# In[2]:


'''處理天氣'''
weather=weather[['縣市','鄉鎮市區','年', '月份', '日期','平均溫度','日雨量','日照時數']]
weather[['縣市','鄉鎮市區','年', '月份', '日期']]=weather[['縣市','鄉鎮市區','年', '月份', '日期']].astype(str)


weather['縣市']=weather['縣市'].apply(lambda x: x.replace('市',''))
weather['縣市']=weather['縣市'].apply(lambda x: x.replace('縣',''))
weather['縣市']=weather['縣市'].apply(lambda x: x.replace('臺','台'))
weather['鄉鎮市區']=weather['鄉鎮市區'].apply(lambda x: x.replace('鄉',''))
weather['鄉鎮市區']=weather['鄉鎮市區'].apply(lambda x: x.replace('鎮',''))
weather['鄉鎮市區']=weather['鄉鎮市區'].apply(lambda x: x.replace('市',''))
weather['鄉鎮市區']=weather['鄉鎮市區'].apply(lambda x: x.replace('區',''))
weather['group_id']=weather['縣市'].astype(str).str.cat(weather[['鄉鎮市區','年', '月份', '日期']],sep=",")
#去除-9999
columns=['平均溫度','日雨量','日照時數']


# In[3]:


for col in tqdm(columns):
    a=weather[weather[col]<-1][col].index
    for index in tqdm(a):
        weather[col][index]=None
    weather[col]=weather[col].fillna(weather[col].mean())
weather['日照時數']=weather['日照時數'].round(2)



# In[4]:


w=weather.groupby('group_id')
wdata=w.agg(np.mean)
wdata=wdata.reset_index()


# In[28]:


real_data=pd.read_csv('invoice_final.csv')


# In[29]:


real_data=real_data.drop(columns=['Unnamed: 0', 'Unnamed: 0.1', 'level_0', 'index', 'Unnamed: 0.1.1'])


# In[54]:


#concat weather and real_data

real_data['group_id']=real_data['date'].apply(lambda x: x.replace('-',','))
real_data['group_id']=real_data['county'].astype(str).str.cat(real_data[['area3','group_id']],sep=',')

#concat cpi
cpi=cpi.dropna(axis=0)
cpi=cpi.rename(columns={" ": "date"})
real_data['cpi_id']=pd.to_datetime(real_data['date'])
real_data['y']=pd.DatetimeIndex(real_data['cpi_id']).year
real_data['m']=pd.DatetimeIndex(real_data['cpi_id']).month.map("{:02}".format)
real_data['cpi_id']=real_data['y'].astype(str).str.cat(real_data['m'].astype(str),sep='-')

#還未merge


# In[7]:


wdata[['p','c','year','month','date']]=pd.DataFrame(wdata.group_id.str.split(',').tolist())


# In[8]:


wdata['zero']='0'


# In[9]:


wdata['month']=wdata['zero'].str.cat(wdata['month'].astype(str),sep='')


# In[10]:


wdata['date']=wdata['date'].apply(lambda x: '0'+x if int(x)<10 else x)


# In[11]:


wdata['group_id']=wdata['p'].str.cat(wdata[['c','year','month','date']],sep=',')


# In[12]:


wdata


# In[30]:


real=pd.merge(real_data,wdata,how='left',on=['group_id'])


# In[31]:


real=real.fillna(-1)


# In[15]:


real_nan=real[real['p']==-1]


# In[16]:


real_nan


# In[17]:


wdata['date_2']=wdata['year'].str.cat(wdata[['month','date']],sep='-')
six_weather=pd.concat([wdata[(wdata['p']=='台北')&(wdata['c']=='中山')],wdata[(wdata['p']=='桃園')&(wdata['c']=='中壢')],wdata[(wdata['p']=='新北')&(wdata['c']=='三峽')],wdata[(wdata['p']=='台中')&(wdata['c']=='北')],wdata[(wdata['p']=='台南')&(wdata['c']=='七股')],wdata[(wdata['p']=='高雄')&(wdata['c']=='三民')]],axis=0)


# In[32]:


real=real.drop(real_nan.index)


# In[34]:


real_nan.head()


# In[20]:


six_weather=pd.merge(real_nan[['inv_time', 'date_x', 'time', 'seller_address', 'inv_id', 'is_holiday',
       'county', 'area', 'area2', 'area3', 'area4', 'area5', 'group_id',
       'cpi_id', 'y', 'm']],six_weather[['平均溫度', '日雨量', '日照時數', 'p', 'c', 'year', 'month', 'date',
       'zero', 'date_2']],left_on=['county','date_x'],right_on=['p','date_2'])


# In[22]:


print(real.columns,six_weather.columns)


# In[23]:


six_weather=six_weather.drop(columns=['date_2'])


# In[35]:


for i,j in zip(real.columns,six_weather.columns):
    six_weather=six_weather.rename(columns={j:i})


# In[36]:


data=pd.concat([real,six_weather],axis=0)


# In[37]:


data['cpi_id']


# In[38]:


data.to_csv('wh_data.csv')


# In[39]:


cpi


# In[40]:


cpi=cpi.dropna(axis=0)


# In[41]:


data['cpi_id']


# In[42]:


final_data=pd.merge(data,cpi,left_on=['cpi_id'],right_on=['date'])


# In[44]:


final_data.to_csv('final_data.csv')


# In[ ]:




